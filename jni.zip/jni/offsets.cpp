// LAIRD ULTRA launcher (Black Russia client) — by laird

#include "offsets.h"
#include "xorstr.h"

std::vector<COffset::stOffset> COffset::m_offsets;

void COffset::Initialise()
{
	Add(xorstr("CNetGame::ProcessNetwork"), 0x1990DBC, eArchType::ARM64);
	Add(xorstr("CNetGame::Packet_TurnLightsSync"), 0x1994CB0, eArchType::ARM64);
	Add(xorstr("CNetGame::Packet_GUI"), 0x1994D98, eArchType::ARM64);
	Add(xorstr("CNetGame::Packet_TrailerSync"), 0x19943FC, eArchType::ARM64);
	Add(xorstr("CNetGame::m_pRakClient"), 0x37809B0, eArchType::ARM64);
	Add(xorstr("CNetGame::m_iGameState"), 0x37809B8, eArchType::ARM64);
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
	Add(xorstr("CNetGame::m_pPlayerPool"), 0x37809C0, eArchType::ARM64);
	Add(xorstr("CNetGame::m_pVehiclePool"), 0x37809C8, eArchType::ARM64);
	Add(xorstr("CNetVehiclePool::New"), 0x19D3024, eArchType::ARM64);
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
	Add(xorstr("CChat::AddDebugMessage"), 0x11061B8, eArchType::ARM64);
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
	Add(xorstr("RakClient::Connect"), 0x1C3E1D0, eArchType::ARM64);
	Add(xorstr("RakClient::Send"), 0x1C3E4D0, eArchType::ARM64);
	Add(xorstr("RakClient::RPC"), 0x1C3EBD8, eArchType::ARM64);
	Add(xorstr("RakClientInterface::Connect"), 0x1C3E270, eArchType::ARM64);
	Add(xorstr("RakClientInterface::Send"), 0x1C3E534, eArchType::ARM64);
	Add(xorstr("RakClientInterface::RPC"), 0x1C3EC44, eArchType::ARM64);
}

void COffset::Add(const char* name, uintptr_t addr, eArchType arch)
{
	stOffset nOffset;
	nOffset.name = name;
	nOffset.addr = addr;
	nOffset.arch = arch;
	m_offsets.push_back(nOffset);
}

uintptr_t COffset::Get(const char* name)
{
	uintptr_t result = 0;
	for(int i = 0; i < m_offsets.size(); i++)
	{
		if(m_offsets[i].arch == eArchType::ARM64)
		{
		if(!strcasecmp(name, m_offsets[i].name.c_str()))
		{
			result = m_offsets[i].addr;
			break;
		}
		}
	}
	return result;
}

// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
