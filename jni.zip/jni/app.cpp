// LAIRD ULTRA launcher (Black Russia client) — by laird

#include "app.h"
#include "plugin.h"


void CApp::Initialise(eAppInit init_type)
{
	if(init_type == eAppInit::APP_INIT_OFFSETS)
	{
		COffset::Initialise();
	}
}