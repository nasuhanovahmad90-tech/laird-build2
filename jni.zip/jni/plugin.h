// LAIRD ULTRA launcher (Black Russia client) — by laird
#pragma once

#include <cstdint>
#include <link.h>
#include <string.h>
#include <jni.h>

#include "offsets.h"

JNIEnv* GetJNIEnv();

class CGameAPI
{
public:
	static uintptr_t GetBase(const char* offsetName = NULL);
	static uintptr_t m_address;
	static bool ValidateEngineBuild();
	static bool IsEngineRange(uintptr_t address, size_t length, bool executable = false);
};

void cp1251_to_utf8(char *out, const char *in, unsigned int len = 0);
