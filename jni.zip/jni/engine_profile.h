// LAIRD ULTRA launcher (Black Russia client) — by laird
#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace EngineProfile
{
inline bool MatchesNote(const unsigned char* notes, size_t size,
                        const unsigned char* expected, size_t expectedSize)
{
    size_t cursor = 0;
    while (size - cursor >= 12) {
        uint32_t nameSize, descSize, type;
        std::memcpy(&nameSize, notes + cursor, 4);
        std::memcpy(&descSize, notes + cursor + 4, 4);
        std::memcpy(&type, notes + cursor + 8, 4);
        cursor += 12;
        const uint64_t nameAligned = (uint64_t(nameSize) + 3) & ~uint64_t(3);
        const uint64_t descAligned = (uint64_t(descSize) + 3) & ~uint64_t(3);
        if (nameAligned > size - cursor || descAligned > size - cursor - nameAligned)
            return false;
        if (type == 3 && nameSize == 4 && descSize == expectedSize &&
            std::memcmp(notes + cursor, "GNU", 4) == 0 &&
            std::memcmp(notes + cursor + nameAligned, expected, expectedSize) == 0)
            return true;
        cursor += static_cast<size_t>(nameAligned + descAligned);
    }
    return false;
}

inline constexpr unsigned char BuildId[] = {0x23, 0xcd, 0xb7, 0x1d, 0x13, 0x94, 0x0c, 0xae, 0xda, 0x16, 0xc9, 0x12, 0xa6, 0xa3, 0xf9, 0x3c, 0x8e, 0x62, 0x5e, 0xe8};
}
