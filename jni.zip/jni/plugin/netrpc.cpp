// LAIRD ULTRA launcher (Black Russia client) — by laird

#include "netrpc.h"
#include "xorstr.h"

#include "plugin.h"
#include "common.h"
#include "netgame.h"
#include "game/chat.h"
#include "vendor/RakNet/StringCompressor.h"
#include <cmath>
#include <cstdio>
#include <cstring>

extern RakClientInterface* pRakClient;

namespace
{
    void LairdBlockedRpc(RPCParameters* p)
    {
        static unsigned int logged = 0;
        if (logged < 64u) {
            ++logged;
        }
    }

    uintptr_t LairdGameRpc(uintptr_t offset)
    {
        return offset ? CGameAPI::m_address + offset : reinterpret_cast<uintptr_t>(&LairdBlockedRpc);
    }

    const char* ToUtf8(const char* text, size_t length, size_t& outLength)
    {
        static char source[4097];
        static char result[4097 * 3];
        if (length > 4096) length = 4096;
        std::memcpy(source, text, length);
        source[length] = '\0';
        cp1251_to_utf8(result, source, static_cast<unsigned int>(length));
        outLength = std::strlen(result);
        return result;
    }

    bool RecodeText8(RakNet::BitStream& in, RakNet::BitStream& out)
    {
        uint8_t length = 0;
        char buffer[256];
        if (!in.Read(length) || !in.Read(buffer, length)) {
            return false;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(buffer, length, utfLength);
        while (utfLength > 255 && (static_cast<unsigned char>(utf[utfLength - 1]) & 0xC0) == 0x80) --utfLength;
        if (utfLength > 255) utfLength = 254;
        out.Write(static_cast<uint8_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        return true;
    }

    bool RecodeCompressedText(RakNet::BitStream& in, RakNet::BitStream& out, int maxChars)
    {
        static char text[4097];
        if (maxChars > 4096) maxChars = 4096;
        text[0] = '\0';
        if (!StringCompressor::Instance()->DecodeString(text, maxChars, &in)) {
            return false;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(text, std::strlen(text), utfLength);
        out.Write(static_cast<uint32_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        return true;
    }

    void CallWithPayload(RPCParameters* p, RakNet::BitStream& out, uintptr_t offset)
    {
        RPCParameters converted = *p;
        converted.input = out.GetData();
        converted.numberOfBitsOfData = out.GetNumberOfBitsUsed();
        reinterpret_cast<void(*)(RPCParameters*)>(LairdGameRpc(offset))(&converted);
    }

    void DialogToNewClient(RPCParameters* p, uintptr_t offset)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 40u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        RakNet::BitStream out;
        uint16_t dialogId = 0;
        uint8_t style = 0;
        if (!in.Read(dialogId) || !in.Read(style)) {
            return;
        }
        out.Write(dialogId);
        out.Write(style);
        for (int i = 0; i < 3; ++i) {
            if (!RecodeText8(in, out)) {
                return;
            }
        }
        if (!RecodeCompressedText(in, out, 4096)) {
            return;
        }
        CallWithPayload(p, out, offset);
    }

    void ClientMessageNew(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 64u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint32_t color = 0, length = 0;
        static char text[4097];
        if (!in.Read(color) || !in.Read(length) || length > 4096u || !in.Read(text, static_cast<int>(length))) {
            return;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(text, length, utfLength);
        RakNet::BitStream out;
        out.Write(color);
        out.Write(static_cast<uint32_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        CallWithPayload(p, out, 0x19ace24);
    }

    void ChatBubbleNew(RPCParameters* p)
    {
        constexpr unsigned int kFixedBytes = 14u;
        if (!p || !p->input || p->numberOfBitsOfData < (kFixedBytes + 1u) * 8u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        RakNet::BitStream out;
        out.Write(reinterpret_cast<const char*>(p->input), kFixedBytes);
        in.SetReadOffset(kFixedBytes * 8u);
        if (!RecodeText8(in, out)) {
            return;
        }
        CallWithPayload(p, out, 0x19b64d4);
    }

    void EditTextDrawNew(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 32u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint16_t id = 0, length = 0;
        char text[1025];
        if (!in.Read(id) || !in.Read(length) || length > 1024u || !in.Read(text, length)) {
            return;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(text, length, utfLength);
        if (utfLength > 0xFFFFu) return;
        RakNet::BitStream out;
        out.Write(id);
        out.Write(static_cast<uint16_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        CallWithPayload(p, out, 0x19b0364);
    }

    void GameTextNew(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 96u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        int32_t style = 0, time = 0;
        uint32_t length = 0;
        static char text[1025];
        if (!in.Read(style) || !in.Read(time) || !in.Read(length) || length > 1024u ||
            !in.Read(text, static_cast<int>(length))) {
            return;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(text, length, utfLength);
        RakNet::BitStream out;
        out.Write(style);
        out.Write(time);
        out.Write(static_cast<uint32_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        CallWithPayload(p, out, 0x19b25c0);
    }

    void ShowDialogNew(RPCParameters* p) { DialogToNewClient(p, 0x19b6618); }
    void ShowDialogExNew(RPCParameters* p) { DialogToNewClient(p, 0x19b684c); }

    void Create3DTextLabelNew(RPCParameters* p)
    {
        constexpr unsigned int kFixedBytes = 27u;
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        RakNet::BitStream out;
        out.Write(reinterpret_cast<const char*>(p->input), kFixedBytes);
        in.SetReadOffset(kFixedBytes * 8u);
        if (!RecodeCompressedText(in, out, 1024)) {
            return;
        }
        CallWithPayload(p, out, 0x19af6e4);
    }
}

namespace
{
    uint16_t ReadLE16(const unsigned char* data)
    {
        return static_cast<uint16_t>(data[0]) |
            static_cast<uint16_t>(static_cast<uint16_t>(data[1]) << 8u);
    }

    void SafeCreate3DTextLabel(RPCParameters* p)
    {
        constexpr unsigned int kFixedBits = 216u;
        constexpr unsigned int kMaxPacketBytes = 8192u;
        constexpr uint16_t kMaxLabelId = 3551u;
        constexpr uint16_t kMaxPlayerId = 1503u;
        constexpr uint16_t kMaxVehicleId = 1999u;
        constexpr uint16_t kInvalidId = 0xFFFFu;

        const unsigned int bits = p ? p->numberOfBitsOfData : 0u;
        const uint64_t bytes64 = (static_cast<uint64_t>(bits) + 7u) / 8u;
        if (!p || !p->input || bits <= kFixedBits || bytes64 > kMaxPacketBytes) {
            return;
        }
        const unsigned int bytes = static_cast<unsigned int>(bytes64);

        const uint16_t labelId = ReadLE16(p->input);
        const uint8_t useLOS = p->input[22];
        const uint16_t attachedPlayer = ReadLE16(p->input + 23);
        const uint16_t attachedVehicle = ReadLE16(p->input + 25);
        float x = 0.0f;
        float y = 0.0f;
        float z = 0.0f;
        float drawDistance = 0.0f;
        std::memcpy(&x, p->input + 6, sizeof(x));
        std::memcpy(&y, p->input + 10, sizeof(y));
        std::memcpy(&z, p->input + 14, sizeof(z));
        std::memcpy(&drawDistance, p->input + 18, sizeof(drawDistance));

        const bool validPlayer = attachedPlayer == kInvalidId || attachedPlayer <= kMaxPlayerId;
        const bool validVehicle = attachedVehicle == kInvalidId || attachedVehicle <= kMaxVehicleId;
        if (labelId > kMaxLabelId || useLOS > 1u || !validPlayer || !validVehicle ||
            !std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z) ||
            !std::isfinite(drawDistance)) {
            return;
        }

        RakNet::BitStream check(p->input, bytes, false);
        check.SetWriteOffset(bits);
        check.SetReadOffset(kFixedBits);
        uint16_t encodedTextBits = 0;
        if (!check.ReadCompressed(encodedTextBits) ||
            check.GetNumberOfUnreadBits() < static_cast<int>(encodedTextBits)) {
            return;
        }

        Create3DTextLabelNew(p);
    }

    void SafeWorldPlayerRemove(RPCParameters* p)
    {
        const unsigned int bits = p ? p->numberOfBitsOfData : 0;
        const unsigned int bytes = (bits + 7u) / 8u;
        if (!p || !p->input || bytes < 2u) {
            return;
        }

        const uint16_t playerId = static_cast<uint16_t>(p->input[0]) |
            static_cast<uint16_t>(static_cast<uint16_t>(p->input[1]) << 8u);
        if (playerId >= 1504u) {
            return;
        }

        CPlayerPool* pool = CNetGame::GetPlayerPool();
        CRemotePlayer* remotePlayer = pool ? pool->GetAt(playerId) : nullptr;
        if (pool && !remotePlayer) {
            return;
        }
        if (remotePlayer && !remotePlayer->m_pPlayerPed) {
            return;
        }

        reinterpret_cast<void(*)(RPCParameters*)>(LairdGameRpc(0x19ad404))(p);
    }
}


namespace
{
    // Called for every chat line, text draw, gang zone and streamed-in vehicle: no log line here
    // (it was a file write + logcat on the game thread each time). Blocked RPCs are still logged.
    void TraceAndCall(const char* name, uintptr_t offset, RPCParameters* params)
    {
        (void)name;
        reinterpret_cast<void(*)(RPCParameters*)>(LairdGameRpc(offset))(params);
    }

	void TraceShowTextDraw(RPCParameters* p)
	{
		const unsigned int bits = p ? p->numberOfBitsOfData : 0;
		const unsigned int bytes = (bits + 7u) / 8u;

		// 65 байт данных TextDraw + 2 байта длины текста
		if(!p || !p->input || bytes < 67)
		{
			return;
		}

		const unsigned int textLength =
			static_cast<unsigned int>(p->input[65]) |
			(static_cast<unsigned int>(p->input[66]) << 8);

		// Пустой ShowTextDraw создаёт у этого клиента белый box на весь экран.
		if(textLength == 0)
		{
			return;
		}

		if(textLength > 255 || bytes < 67u + textLength)
		{
			return;
		}

		TraceAndCall("ShowTextDraw", 0x0, p);
	}

    void TraceAddGangZone(RPCParameters* p)    { TraceAndCall("AddGangZone", 0x19bebc8, p); }
    void TraceFlashGangZone(RPCParameters* p)  { TraceAndCall("FlashGangZone", 0x19bedd0, p); }
    void TraceWorldVehicleAdd(RPCParameters* p)
    {
        reinterpret_cast<void(*)(RPCParameters*)>(LairdGameRpc(0x19adefc))(p);
    }

}

// Game features BR has handlers for but this launcher never routed (found from the game's own RPC table).
// SA-MP has no RPC ids for most of them, so the server sends them on free ids 210-216.
namespace
{
    int g_rpcMaxHealth = 210;            // u16 player, f32 max health (the nametag bar is health / max)
    int g_rpcMaxArmour = 211;            // u16 player, f32 max armour
    int g_rpcEntityOutline = 212;        // u8 type, u16 id, u8 on; on: f32 width 0-10, f32, u8, u32 color
    int g_rpcRadioStream = 213;          // u32, str8 url, str8 name, u8 attach, u16 id, ...
    int g_rpcUpdateLabel = 214;          // u16 label, u32 color, compressed text
    int g_rpcActorAttachedObject = 215;  // like SetPlayerAttachedObject for an actor, without colors
    int g_rpcDialogEx = 216;             // same layout as ShowPlayerDialog, other game window

    uintptr_t GameHandler(uintptr_t arm32_thumb, uintptr_t arm64)
    {
        (void)arm32_thumb;
        return LairdGameRpc(arm64);
    }

    // SA-MP sends lights and tires as one byte each; the game reads two bytes for each.
    void DamageVehicleToGame(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 96u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint16_t vehicle = 0;
        uint32_t panels = 0, doors = 0;
        uint8_t lights = 0, tires = 0;
        if (!in.Read(vehicle) || !in.Read(panels) || !in.Read(doors) || !in.Read(lights) || !in.Read(tires)) {
            return;
        }
        RakNet::BitStream out;
        out.Write(vehicle);
        out.Write(panels);
        out.Write(doors);
        out.Write(static_cast<uint16_t>(lights));
        out.Write(static_cast<uint16_t>(tires));
        RPCParameters converted = *p;
        converted.input = out.GetData();
        converted.numberOfBitsOfData = out.GetNumberOfBitsUsed();
        reinterpret_cast<void(*)(RPCParameters*)>(GameHandler(0x332A45, 0x19b1ed4))(&converted);
    }

    void RegisterGameExtraRPCs(RakClientInterface* pInterface)
    {
        using Handler = void (*)(RPCParameters*);
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcMaxHealth, reinterpret_cast<Handler>(GameHandler(0x33A399, 0x19bf470)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcMaxArmour, reinterpret_cast<Handler>(GameHandler(0x33A435, 0x19bf564)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcEntityOutline, reinterpret_cast<Handler>(GameHandler(0x339375, 0x19be6a8)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcRadioStream, reinterpret_cast<Handler>(GameHandler(0x330D59, 0x19afad4)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcUpdateLabel, reinterpret_cast<Handler>(GameHandler(0x331009, 0x0)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcActorAttachedObject, reinterpret_cast<Handler>(GameHandler(0x3358E9, 0x0)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcDialogEx, ShowDialogExNew);
        // Same layout as SA-MP: SetObjectPos (45), RemoveVehicleComponent (57).
        pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetObjectPos, reinterpret_cast<Handler>(GameHandler(0x333825, 0x19b43f4)));
        pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrRemoveComponent, reinterpret_cast<Handler>(GameHandler(0x332491, 0x19b1738)));
        pInterface->RegisterAsRemoteProcedureCall(&RPC_DamageVehicle, DamageVehicleToGame);
    }
}

void RegisterRPCs(RakClientInterface* pInterface)
{
  // 64 bit - ЗАМЕНЕННЫЕ оффсеты для нового билда
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrMoveObject, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19bef80)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleZAngle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1830)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerColor, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b29ec)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraPos, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0748)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetRaceCheckpoint, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b7eec)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_StopAudioStream, LairdBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraLookAt, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0848)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrVehicleParams, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b54ac)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrAddGangZone, TraceAddGangZone);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerSkin, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0a88)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_UpdateScoresPingsIPs, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b919c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrResetPlayerWeapons, LairdBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDetachTrailerFromVehicle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19bf3a0)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrFlashGangZone, TraceFlashGangZone);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ConnectionRejected, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19ad6e0)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ServerQuit, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19acd48)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleVelocity, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1924)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_Weather, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1c60)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrResetMoney, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1374)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerHealth, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1034)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrStopObject, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b4540)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehiclePos, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1614)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleHealth, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b152c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrClearPlayerAnimations, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b7530)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetActorFacingAngle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2444)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerArmour, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b10fc)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDisableMapIcon, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b8384)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScmEvent, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19bf168)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrApplyPlayerAnimation, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b6f54)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldPlayerDeath, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19af01c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetCheckpoint, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b7cbc)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrClearActorAnimations, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b7b9c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrRemovePlayerFromVehicle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1478)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrTogglePlayerSpectating, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b51b8)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrStopFlashGangZone, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19beeb4)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_EnterVehicle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19aee0c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ShowActor, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2018)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetObjectRotation, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b4610)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerPosFindZ, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2dc0)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrInterpolateCamera, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19be988)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetActorHealth, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2264)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_InitGame, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19ac434)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrGivePlayerWeapon, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19af310)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrAttachTrailerToVehicle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19bf2b8)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetTimeEx, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1dec)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetWeaponAmmo, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19af3f0)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrHaveSomeMoney, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b12a8)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerWantedLevel, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2c68)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDialogBox, ShowDialogNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerVelocity, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1a38)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetMapIcon, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b8190)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldVehicleAdd, TraceWorldVehicleAdd);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDestroyObject, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b41b4)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrLinkVehicle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1390)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ClientMessage, ClientMessageNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerFacingAngle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0944)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_DisableCheckpoint, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b7e78)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrShowTextDraw, TraceShowTextDraw);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldTime, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b1d28)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_PlayAudioStream, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b9bb4)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetArmedWeapon, LairdBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldVehicleRemove, LairdBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrApplyActorAnimation, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b7678)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldPlayerRemove, SafeWorldPlayerRemove);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ExitVehicle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19aef28)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_DisableRaceCheckpoint, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b811c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_Pickup, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19af4d4)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSelectTextDraw, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0474)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ChatBubble, ChatBubbleNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetInterior, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0f50)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrHideTextDraw, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0298)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCreateExplosion, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2740)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetActorPos, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2354)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_HideActor, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b21a8)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrPlayerSpectatePlayer, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b528c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrEditTextDraw, EditTextDrawNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrPutPlayerInVehicle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b11c4)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCreate3DTextLabel, SafeCreate3DTextLabel);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetSpawnInfo, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0608)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraBehindPlayer, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b0f18)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerPos, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19af0ec)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_DestroyPickup, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19af61c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrVehicleParamsEx, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b55b4)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrTogglePlayerControllable, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b286c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrPlayerSpectateVehicle, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b539c)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ServerJoin, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19acb64)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrRemoveGangZone, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19bed04)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldPlayerAdd, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19acff8)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_RequestSpawn, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19acfd4)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDisplayGameText, GameTextNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerName, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2b64)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerAttachedObject, LairdBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCustomizeVehicle, LairdBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCommonStuff, LairdBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCreateObject, ((void (*)(RPCParameters*))(CGameAPI::m_address + 0x19b2ed8)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCreateWayPoint, (void (*)(RPCParameters*))((CGameAPI::m_address + 0x4FA7A4)));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDestroyWayPoint, (void (*)(RPCParameters*))((CGameAPI::m_address + 0x004FA904)));
  RegisterGameExtraRPCs(pInterface);
}


