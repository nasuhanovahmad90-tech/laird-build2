// LAIRD ULTRA launcher (Black Russia client) — by laird
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

#include "vendor/RakNet/BitStream.h"
#include "vendor/RakNet/SAMP/SAMPRPC.h"
#include "vendor/RakNet/PacketPriority.h"

#include "game/math/vector.h"

enum BRPacketEnumeration : int32_t
{
    BR_ID_USER_INTERFACE_SYNC = 27,
    BR_ID_AIM_SYNC = 38,
    BR_ID_WEAPONS_UPDATE = 35,
    BR_ID_STATS_UPDATE = 0xF1,
    BR_ID_PASSENGER_SYNC = 0xF2,
    BR_ID_TRAILER_SYNC = 31,
    BR_ID_PLAYER_SYNC = 30,
    BR_ID_UNOCCUPIED_SYNC = 32,
    BR_ID_SPECTATOR_SYNC = 37,
    BR_ID_BULLET_SYNC = 29,
    BR_ID_VEHICLE_SYNC = 34,
    BR_ID_TURNLIGHTS_SYNC = 0xF3,
    BR_ID_USER_PACKET_ENUM = 0xD,
    BR_ID_CONNECTION_ATTEMPT_FAILED = 0xE,
    BR_ID_DISCONNECTION_NOTIFICATION = 0xF,
    BR_ID_NO_FREE_INCOMING_CONNECTIONS = 0x10,
    BR_ID_CONNECTION_REQUEST_ACCEPTED = 0x11,
    BR_ID_TIMESTAMP = 0x12,
    BR_ID_PONG = 0x13,
    BR_ID_CONNECTION_BANNED = 0x14,
    BR_ID_CONNECTION_LOST = 0x15,
    BR_ID_MODIFIED_PACKET = 0x16,
    BR_ID_NEW_INCOMING_CONNECTION = 0x17,
    BR_ID_INVALID_PASSWORD = 0x18,
    BR_ID_QUEUE_UPDATE = 0x19,
    BR_ID_QUEUE_LEFT = 0x1A,
    BR_ID_RPC = 0x1B,
    BR_ID_DETECT_LOST_CONNECTIONS = 0x1C,
    BR_ID_OPEN_CONNECTION_REPLY = 0x1D,
    BR_ID_CONNECTED_PONG = 0x1E,
    BR_ID_PING_OPEN_CONNECTIONS = 0x1F,
    BR_ID_AUTH_KEY = 0x20,
    BR_ID_PING = 0x21,
    BR_ID_INTERNAL_PING = 0x22,
    BR_ID_OPEN_CONNECTION_REQUEST = 0x23,
    BR_ID_CONNECTION_REQUEST = 0x24,
    BR_ID_REQUEST_STATIC_DATA = 0x25,
    BR_ID_SECURED_CONNECTION_RESPONSE = 0x26,
    BR_ID_SECURED_CONNECTION_CONFIRMATION = 0x27,
    BR_ID_RPC_MAPPING = 0x28,
    BR_ID_RPC_REPLY = 0x29,
    BR_ID_BROADCAST_PINGS = 0x2A,
    BR_ID_SET_RANDOM_NUMBER_SEED = 0x2B,
    BR_ID_RSA_PUBLIC_KEY_MISMATCH = 0x2C,
    BR_ID_RECEIVED_STATIC_DATA = 0x2D,
    BR_ID_REMOTE_DISCONNECTION_NOTIFICATION = 0x2E,
    BR_ID_REMOTE_CONNECTION_LOST = 0x2F,
    BR_ID_REMOTE_NEW_INCOMING_CONNECTION = 0x30,
    BR_ID_REMOTE_EXISTING_CONNECTION = 0x31,
    BR_ID_REMOTE_STATIC_DATA = 0x32,
    BR_ID_ADVERTISE_SYSTEM = 0x33,
    BR_ID_OPEN_CONNECTION_COOKIE = 0x34,
};

enum BRRpcIds : int32_t
{
    BR_RPC_ClientJoin = 0x7f00,
    BR_RPC_ScrSetPlayerPos = 448,
    BR_RPC_WorldActorRemove = 318,
    BR_RPC_ScrSetActorAttachedObject = 0x7f01,
    BR_RPC_ScrTogglePlayerSpectating = 330,
    BR_RPC_Spawn = 441,
    BR_RPC_ScrClearActorAnimations = 333,
    BR_RPC_ScrSetMapIcon = 307,
    BR_RPC_EnterVehicle = 382,
    BR_RPC_ScrSetSpecialAction = 0x7f02,
    BR_RPC_ScrFlashGangZone = 359,
    BR_RPC_Chat = 414,
    BR_RPC_ScrDetachTrailerFromVehicle = 366,
    BR_RPC_ClientInfo = 413,
    BR_RPC_ScrSetSpawnInfo = 372,
    BR_RPC_ScrGivePlayerWeapon = 433,
    BR_RPC_ScrSetActorHealth = 350,
    BR_RPC_SelectObject = 0x7f03,
    BR_RPC_RequestClass = 361,
    BR_RPC_PickedUpPickup = 436,
    BR_RPC_ShowDialogEx = 368,
    BR_RPC_ServerQuit = 326,
    BR_RPC_ScrSetPlayerArmour = 315,
    BR_RPC_ScrSetPlayerPosFindZ = 416,
    BR_RPC_ScrSetObjectRotation = 446,
    BR_RPC_QueueGame = 358,
    BR_RPC_ChatBubble = 375,
    BR_RPC_ScrLinkVehicleToInterior = 383,
    BR_RPC_ScrSetInterior = 434,
    BR_RPC_ScrDisableMapIcon = 410,
    BR_RPC_ScrCreateObject = 391,
    BR_RPC_ScrDestroyObject = 388,
    BR_RPC_ScrSetVehicleZAngle = 327,
    BR_RPC_WorldPlayerDeath = 435,
    BR_RPC_DisableCheckpoint = 430,
    BR_RPC_ScrRemovePlayerFromVehicle = 339,
    BR_RPC_ScrAttachCameraToObject = 0x7f04,
    BR_RPC_ScrPlaySound = 0x7f05,
    BR_RPC_SetVehicleParamsEx = 411,
    BR_RPC_ObjectCollision = 314,
    BR_RPC_ScrSelectTextDraw = 376,
    BR_RPC_DialogResponse = 0x7f06,
    BR_RPC_ScrSetActorFacingAngle = 422,
    BR_RPC_ScrClientAction = 323,
    BR_RPC_EditAttachedObject = 0x7f07,
    BR_RPC_ScrPlayerSpectatePlayer = 308,
    BR_RPC_WorldVehicleAdd = 329,
    BR_RPC_Death = 371,
    BR_RPC_ScrSetVehicleVelocity = 334,
    BR_RPC_ScrDisplayGameText = 415,
    BR_RPC_ConnectionRejected = 319,
    BR_RPC_SetPlayerSkillLevel = 0x7f08,
    BR_RPC_ScrSetVehicleHealth = 331,
    BR_RPC_MapMarker = 423,
    BR_RPC_ScrRemoveGangZone = 346,
    BR_RPC_ScrResetPlayerWeapons = 0x7f09,
    BR_RPC_ScrSetPlayerVelocity = 335,
    BR_RPC_ScrHideTextDraw = 354,
    BR_RPC_ScrSetMaxHealth = 439,
    BR_RPC_ScrInterpolateCamera = 316,
    BR_RPC_UpdateScoresPingsIPs = 374,
    BR_RPC_ShowDialog = 347,
    BR_RPC_ScrPlayAudioStream = 313,
    BR_RPC_SetGlobalTimer = 0x7f0a,
    BR_RPC_ScrSetObjectMaterial = 0x7f0b,
    BR_RPC_DisableRaceCheckpoint = 304,
    BR_RPC_ScrClearAnimations = 311,
    BR_RPC_ServerCommand = 378,
    BR_RPC_VehicleDestroyed = 0x7f0c,
    BR_RPC_WorldPlayerAdd = 419,
    BR_RPC_ScrStopFlashGangZone = 369,
    BR_RPC_ScrSetPlayerColor = 447,
    BR_RPC_WorldTime = 340,
    BR_RPC_WorldVehicleRemove = 0x7f0d,
    BR_RPC_ClickTextDraw = 437,
    BR_RPC_ScrSetPlayerSkin = 400,
    BR_RPC_DestroyWaypoint = 322,
    BR_RPC_InitGame = 421,
    BR_RPC_ScrStopObject = 306,
    BR_RPC_ScrSetArmedWeapon = 403,
    BR_RPC_ClientMessage = 360,
    BR_RPC_ScrRemoveVehicleComponent = 395,
    BR_RPC_SetCheckpoint = 440,
    BR_RPC_CreateWaypoint = 417,
    BR_RPC_ScrSetMaxArmour = 328,
    BR_RPC_ScrSetPlayerAttachedObject = 0x7f0f,
    BR_RPC_CancelEdit = 0x7f10,
    BR_RPC_ScrSetPlayerName = 384,
    BR_RPC_WorldActorAdd = 424,
    BR_RPC_ScrPlayerSpectateVehicle = 389,
    BR_RPC_ScrCreateExplosion = 338,
    BR_RPC_DamageVehicle = 431,
    BR_RPC_ScrEditTextDraw = 349,
    BR_RPC_WorldPlayerRemove = 325,
    BR_RPC_ScrAttachObjectToPlayer = 0x7f11,
    BR_RPC_ScrAttachTrailerToVehicle = 351,
    BR_RPC_ScrPutPlayerInVehicle = 353,
    BR_RPC_ScrShowTextDraw = 418,
    BR_RPC_ScmEvent = 425,
    BR_RPC_ScrApplyActorAnimation = 336,
    BR_RPC_SetRaceCheckpoint = 385,
    BR_RPC_ScrSetVehiclePos = 412,
    BR_RPC_Weather = 379,
    BR_RPC_ScrSetPlayerHealth = 387,
    BR_RPC_DestroyPickup = 373,
    BR_RPC_Pickup = 377,
    BR_RPC_ScrSetObjectPos = 443,
    BR_RPC_EditObject = 0x7f12,
    BR_RPC_ScrAddGangZone = 393,
    BR_RPC_RequestSpawn = 344,
    BR_RPC_ScrApplyAnimation = 345,
    BR_RPC_ScrResetMoney = 348,
    BR_RPC_ScrTogglePlayerControllable = 428,
    BR_RPC_SetTimeEx = 394,
    BR_RPC_ScrSetWeaponAmmo = 303,
    BR_RPC_Create3DTextLabel = 432,
    BR_RPC_Update3DTextLabel = 309,
    BR_RPC_PlayerGiveTakeDamage = 356,
    BR_RPC_ScrSetCameraLookAt = 405,
    BR_RPC_ServerJoin = 401,
    BR_RPC_ScrStopAudioStream = 312,
    BR_RPC_ScrSetCameraBehindPlayer = 302,
    BR_RPC_ScrMoveObject = 408,
    BR_RPC_ScrSetActorPos = 426,
    BR_RPC_ScrHaveSomeMoney = 362,
    BR_RPC_ActorGiveDamage = 355,
    BR_RPC_ScrSetEntityOutline = 399,
    BR_RPC_SetInteriorId = 357,
    BR_RPC_ScrSetPlayerWantedLevel = 398,
    BR_RPC_ScrSetFightingStyle = 0x7f13,
    BR_RPC_ScrSetPlayerDrunkLevel = 0x7f14,
    BR_RPC_ScrSetPlayerFacingAngle = 365,
    BR_RPC_ScrSetCameraPos = 310,
    BR_RPC_ScrShowNameTag = 0x7f15,
    BR_RPC_ExitVehicle = 409,
    BR_RPC_ScrVehicleParams = 402,
    BR_RPC_ProjectileHit = 342,
    BR_RPC_ScrPlayRadioStream = 337,
    BR_RPC_ScrCustomizeVehicle = 429,
    BR_RPC_ScrCommonStuff = 323
};

enum BRPacketReliability : int32_t
{
	BR_RELIABILITY_UNRELIABLE = 0x0,
	BR_RELIABILITY_UNRELIABLE_SEQUENCED = 0x1,
	BR_RELIABILITY_RELIABLE = 0x2,
	BR_RELIABILITY_RELIABLE_ORDERED = 0x3,
	BR_RELIABILITY_RELIABLE_SEQUENCED = 0x4
};

int ConvertBRIDToSampID(BRRpcIds value);
PacketReliability ConvertBRToSampReliability(BRPacketReliability reliability);

struct BRAimSyncData
{
	uint8_t byteCamMode;
	CVector vecAimf1;
	CVector vecAimPos;
	float fAimZ;
	uint8_t byteCamExtZoomAndWeaponState;
	uint8_t byteAspectRatio;
};

static_assert(sizeof(BRAimSyncData) == 36, "BRAimSyncData ABI mismatch");
static_assert(offsetof(BRAimSyncData, vecAimf1) == 4, "BRAimSyncData::vecAimf1 ABI mismatch");
static_assert(offsetof(BRAimSyncData, vecAimPos) == 16, "BRAimSyncData::vecAimPos ABI mismatch");
static_assert(offsetof(BRAimSyncData, fAimZ) == 28, "BRAimSyncData::fAimZ ABI mismatch");

typedef struct _BROnFootSyncData
{
	int16_t lrAnalogLeftStick;
	int16_t udAnalogLeftStick;
	uint16_t wKeys;
	CVector vecPos;
	float quatw;
	float quatx;
	float quaty;
	float quatz;
	uint16_t health;
	uint16_t armour;
	uint8_t byteCurrentWeapon;
	uint8_t byteSpecialAction;
	CVector vecMoveSpeed;
	CVector vecSurfOffsets;
	uint16_t wSurfInfo;
	uint32_t dwAnimation;
} BROnFootSyncData;

static_assert(sizeof(BROnFootSyncData) == 76, "BROnFootSyncData ABI mismatch");
static_assert(offsetof(BROnFootSyncData, vecPos) == 8, "BROnFootSyncData::vecPos ABI mismatch");
static_assert(offsetof(BROnFootSyncData, health) == 36, "BROnFootSyncData::health ABI mismatch");
static_assert(offsetof(BROnFootSyncData, vecMoveSpeed) == 44, "BROnFootSyncData::vecMoveSpeed ABI mismatch");
static_assert(offsetof(BROnFootSyncData, dwAnimation) == 72, "BROnFootSyncData::dwAnimation ABI mismatch");

struct BRInCarSyncData
{
	uint16_t VehicleID;
	uint16_t lrAnalogLeftStick;
	uint16_t udAnalogLeftStick;
	uint16_t wKeys;
	float quatw;
	float quatx;
	float quaty;
	float quatz;
	CVector vecPos;
	CVector vecMoveSpeed;
	float fCarHealth;
	uint16_t playerHealth;
	uint16_t playerArmour;
	uint8_t byteCurrentWeapon;
	uint8_t byteSirenOn;
	uint8_t byteLandingGearState;
	uint16_t TrailerID;
	int16_t lrAnalogRightStick;
	int16_t udAnalogRightStick;
};

static_assert(sizeof(BRInCarSyncData) == 68, "BRInCarSyncData ABI mismatch");
static_assert(offsetof(BRInCarSyncData, TrailerID) == 60, "BRInCarSyncData::TrailerID ABI mismatch");
static_assert(offsetof(BRInCarSyncData, udAnalogRightStick) == 64, "BRInCarSyncData::udAnalogRightStick ABI mismatch");

struct BRPassengerSyncData
{
	uint16_t VehicleID;
	uint8_t byteSeatFlags : 7;
	uint8_t byteDriveBy : 1;
	uint8_t byteCurrentWeapon;
	uint16_t playerHealth;
	uint16_t playerArmour;
	uint16_t lrAnalog;
	uint16_t udAnalog;
	uint16_t wKeys;
	CVector vecPos;
};

static_assert(sizeof(BRPassengerSyncData) == 28, "BRPassengerSyncData ABI mismatch");
static_assert(offsetof(BRPassengerSyncData, vecPos) == 16, "BRPassengerSyncData::vecPos ABI mismatch");

struct BRUnoccupiedSyncData
{
	uint16_t VehicleID;
	uint8_t byteSeatID;
	uint8_t bytePadding;
	CVector vecRoll;
	CVector vecDirection;
	CVector vecPos;
	CVector vecMoveSpeed;
	CVector vecTurnSpeed;
	float fHealth;
};

static_assert(sizeof(BRUnoccupiedSyncData) == 68, "BRUnoccupiedSyncData ABI mismatch");
static_assert(offsetof(BRUnoccupiedSyncData, vecRoll) == 4, "BRUnoccupiedSyncData::vecRoll ABI mismatch");
static_assert(offsetof(BRUnoccupiedSyncData, fHealth) == 64, "BRUnoccupiedSyncData::fHealth ABI mismatch");

#pragma pack(push, 1)
struct OnFootSyncData
{
	int16_t lrAnalog;
	int16_t udAnalog;
	uint16_t wKeys;
	CVector vecPos;
	float quatw;
	float quatx;
	float quaty;
	float quatz;
	uint8_t byteHealth;
	uint8_t byteArmour;
	uint8_t byteCurrentWeapon;
	uint8_t byteSpecialAction;
	CVector vecMoveSpeed;
	CVector vecSurfOffsets;
	uint16_t wSurfInfo;
	uint32_t dwAnimation;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct InCarSyncData
{
	uint16_t VehicleID;
	uint16_t lrAnalog;
	uint16_t udAnalog;
	uint16_t wKeys;
	float quatw;
	float quatx;
	float quaty;
	float quatz;
	CVector vecPos;
	CVector vecMoveSpeed;
	float fCarHealth;
	uint8_t bytePlayerHealth;
	uint8_t bytePlayerArmour;
	uint8_t byteCurrentWeapon;
	uint8_t byteSirenOn;
	uint8_t byteLandingGearState;
	uint16_t TrailerID;
	float fTrainSpeed;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct PassengerSyncData
{
	uint16_t VehicleID;
	uint8_t byteSeatFlags : 7;
	uint8_t byteDriveBy : 1;
	uint8_t byteCurrentWeapon;
	uint8_t bytePlayerHealth;
	uint8_t bytePlayerArmour;
	uint16_t lrAnalog;
	uint16_t udAnalog;
	uint16_t wKeys;
	CVector vecPos;
};
#pragma pack(pop)

struct BRNewVehiclePacked
{
	uint16_t VehicleID;
	int iVehicleType;
	CVector vecPos;
	float fRotation;
	uint8_t aColor1;
	uint8_t aColor2;
	float fHealth;
	uint8_t byteInterior;
	uint32_t dwDoorDamageStatus;
	uint32_t dwPanelDamageStatus;
	uint8_t byteLightDamageStatus;
	uint8_t byteTireDamageStatus;
	uint8_t byteAddSiren;
	uint16_t byteModSlots[2];
	int32_t cColor1;
	int32_t cColor2;
	uint32_t dwWindowsColor;
	uint32_t dwWindowsColor2;
	uint32_t dwWindowsColor3;
	uint32_t dwWindowsColor4;
	float fSuspensionForce;
	float fSuspensionCenter;
	float fWheelSize;
	float fMaxSpeed;
	float fEngineAcceleration;
	float fSteeringLock;
	uint32_t dwLightsColor;
	uint32_t dwNeonColor;
	uint32_t dwNeonColor2;
	uint32_t dwNeonColor3;
	float fWheelsAngle;
	float fWheelsAngleRear;
	uint32_t dwWheelsWidth;
	uint8_t bDriftMode;
	float fWheelsOffset;
	float fWheelsOffsetRear;
	float fWheelScale;
	float fWheelScaleRear;
	uint32_t dwColor[4];
	uint8_t bHornTon;
	uint32_t dwStrobesMode;
	uint32_t dwChipMode;
	uint8_t bHydauliks;
	uint8_t bFar;
	int16_t wExhaust;
	uint8_t bUseSiren;
	uint8_t bEnabledSiren;
};

void ConvertBROnFootSyncToSampSync(RakNet::BitStream*, BROnFootSyncData);
void ConvertBRInCarSyncToSampSync(RakNet::BitStream*, BRInCarSyncData);
void ConvertBRPassengerSyncToSampSync(RakNet::BitStream*, BRPassengerSyncData);

bool IsRPCNeedFix(int rpcId);
void FixBrokenRPC(int rpcId, RPCParameters* rpcParams, void (*staticFunc)(RPCParameters*));
