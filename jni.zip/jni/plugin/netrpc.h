// LAIRD ULTRA launcher (Black Russia client) — by laird
#pragma once

#include "vendor/RakNet/RakNetworkFactory.h"
#include "vendor/RakNet/RakClient.h"
#include "vendor/RakNet/SAMP/SAMPRPC.h"

void RegisterRPCs(RakClientInterface* pInterface);

