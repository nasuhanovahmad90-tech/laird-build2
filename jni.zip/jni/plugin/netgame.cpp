// LAIRD ULTRA launcher (Black Russia client) — by laird

#include "netgame.h"
#include "xorstr.h"
#include "plugin.h"
#include "../client_config.h"
#include <cmath>
#include <cstring>
#include <ctime>
#include <new>
#include <pthread.h>

#define NETGAME_VERSION 4057

extern RakClientInterface* pRakClient;

std::atomic<uint16_t> CNetGame::m_nLastSAMPDialogID {0};

namespace
{
constexpr uint16_t kPlayerPoolSize = 1504;
constexpr uint32_t kMaxPacketsPerProcessTick = 1024;
constexpr uint64_t kReconnectDelayMs = 15000;
constexpr uint32_t kMaxGuiPayloadSize = 1u << 20;
constexpr size_t kMaxPendingGuiMessages = 64;
constexpr size_t kMaxServerHostLength = 255;
constexpr const char* kMainServerHost = ClientConfig::ServerHost;
constexpr uint16_t kMainServerPort = ClientConfig::ServerPort;

bool gReconnectPending = false;
uint64_t gReconnectAtMs = 0;
char gServerHost[kMaxServerHostLength + 1] = {};
uint16_t gServerPort = kMainServerPort;
pthread_mutex_t gServerEndpointMutex = PTHREAD_MUTEX_INITIALIZER;

struct PendingGuiMessage
{
    int guiId = 0;
    char* data = nullptr;
    uint32_t length = 0;
};

PendingGuiMessage gPendingGuiMessages[kMaxPendingGuiMessages] {};
size_t gPendingGuiRead = 0;
size_t gPendingGuiWrite = 0;
size_t gPendingGuiCount = 0;
bool gGuiSessionActive = false;
pthread_mutex_t gPendingGuiMutex = PTHREAD_MUTEX_INITIALIZER;

bool QueueGuiMessage(int guiId, const char* data, uint32_t length)
{
    if (guiId < 0 || guiId > 0xFFFF || length > kMaxGuiPayloadSize ||
        (!data && length != 0)) {
        return false;
    }

    char* ownedData = nullptr;
    if (length != 0) {
        ownedData = new (std::nothrow) char[length];
        if (!ownedData) {
            return false;
        }
        std::memcpy(ownedData, data, length);
    }

    pthread_mutex_lock(&gPendingGuiMutex);
    if (!gGuiSessionActive || gPendingGuiCount == kMaxPendingGuiMessages) {
        pthread_mutex_unlock(&gPendingGuiMutex);
        delete[] ownedData;
        return false;
    }

    PendingGuiMessage& slot = gPendingGuiMessages[gPendingGuiWrite];
    slot.guiId = guiId;
    slot.data = ownedData;
    slot.length = length;
    gPendingGuiWrite = (gPendingGuiWrite + 1) % kMaxPendingGuiMessages;
    ++gPendingGuiCount;
    pthread_mutex_unlock(&gPendingGuiMutex);
    return true;
}

void FlushQueuedGuiMessages()
{
    for (size_t processed = 0; processed < kMaxPendingGuiMessages; ++processed) {
        PendingGuiMessage message;

        pthread_mutex_lock(&gPendingGuiMutex);
        if (gPendingGuiCount == 0) {
            pthread_mutex_unlock(&gPendingGuiMutex);
            return;
        }

        message = gPendingGuiMessages[gPendingGuiRead];
        gPendingGuiMessages[gPendingGuiRead] = PendingGuiMessage {};
        gPendingGuiRead = (gPendingGuiRead + 1) % kMaxPendingGuiMessages;
        --gPendingGuiCount;
        // Send uses our own RakClient and cannot re-enter the engine Send hook.
        // Keep the session lock until it returns, so Connect cannot reset mid-send.
        if (gGuiSessionActive && pRakClient) {
            if (message.guiId == 10) {
                RakNet::BitStream response(reinterpret_cast<unsigned char*>(message.data), message.length, false);
                pRakClient->RPC(&RPC_DialogResponse, &response, HIGH_PRIORITY,
                                      RELIABLE_ORDERED, 0, false, UNASSIGNED_NETWORK_ID, nullptr);
            } else {
                CNetGame::SendJsonData(message.guiId, message.data, message.length);
            }
        }
        pthread_mutex_unlock(&gPendingGuiMutex);
        delete[] message.data;
    }
}

uint64_t GetMonotonicTimeMs()
{
    struct timespec ts {};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<uint64_t>(ts.tv_sec) * 1000u +
           static_cast<uint64_t>(ts.tv_nsec) / 1000000u;
}

void CancelReconnect()
{
    gReconnectPending = false;
    gReconnectAtMs = 0;
}

void ScheduleReconnect()
{
    if (gReconnectPending) {
        return;
    }

    CNetGame::ResetGuiSession();
    gReconnectPending = true;
    gReconnectAtMs = GetMonotonicTimeMs() + kReconnectDelayMs;
    CChat::AddDebugMessage(xorstr("Переподключение через 15 секунд..."));

    CNetGame::SetGameState(GAMESTATE_DISCONNECTED);
    if (pRakClient) {
        // Дожидаемся остановки сетевого потока, чтобы следующий Connect не
        // получил false из-за ещё активного старого соединения.
        pRakClient->Disconnect(100, 0);
    }
}

bool StoreServerEndpoint(const char* host, uint16_t port)
{
    if (!host || port == 0) {
        return false;
    }

    size_t length = 0;
    while (length <= kMaxServerHostLength && host[length] != '\0') {
        ++length;
    }
    if (length == 0 || length > kMaxServerHostLength) {
        return false;
    }

    const bool isMainServer =
        port == kMainServerPort && std::strcmp(host, kMainServerHost) == 0;
    if (!isMainServer) {
        return false;
    }

    pthread_mutex_lock(&gServerEndpointMutex);
    std::memcpy(gServerHost, host, length);
    gServerHost[length] = '\0';
    gServerPort = port;
    pthread_mutex_unlock(&gServerEndpointMutex);
    return true;
}

void CopyServerEndpoint(char* host, size_t capacity, uint16_t& port)
{
    pthread_mutex_lock(&gServerEndpointMutex);
    std::memcpy(host, gServerHost, capacity);
    host[capacity - 1] = '\0';
    port = gServerPort;
    pthread_mutex_unlock(&gServerEndpointMutex);
}

void ProcessReconnectTimer()
{
    if (!gReconnectPending) {
        return;
    }

    if (GetMonotonicTimeMs() < gReconnectAtMs) {
        // Не даём штатному пят-секундному таймеру запустить Connect раньше.
        if (CNetGame::GetGameState() != GAMESTATE_DISCONNECTED) {
            CNetGame::SetGameState(GAMESTATE_DISCONNECTED);
        }
        return;
    }

    CancelReconnect();
    if (!pRakClient) {
        ScheduleReconnect();
        return;
    }

    CNetGame::ResetGuiSession();
    CChat::AddDebugMessage("Соединение с %s", ClientConfig::ServerName);
    CNetGame::SetGameState(GAMESTATE_CONNECTING);
    char serverHost[kMaxServerHostLength + 1] {};
    uint16_t serverPort = 0;
    CopyServerEndpoint(serverHost, sizeof(serverHost), serverPort);
    if (!serverHost[0] || !serverPort) {
        std::strncpy(serverHost, ClientConfig::ServerHost, kMaxServerHostLength);
        serverPort = ClientConfig::ServerPort;
    }
    const bool started = pRakClient->Connect(
        serverHost, serverPort, 0, 0, 5
    );

    if (!started) {
        CNetGame::SetGameState(GAMESTATE_DISCONNECTED);
        ScheduleReconnect();
    }
}

// The name argument is decrypted (xorstr) by the caller each time; resolve through this macro so the
// lookup and decryption happen only until the address is found.
#define LAIRD_GAME_ADDRESS(cache, name) ((cache) ? (cache) : ((cache) = CGameAPI::GetBase(xorstr(name))))

struct NewGamePacket
{
    uint64_t sender;
    uint32_t length;
    uint32_t bitSize;
    unsigned char* data;
    uint64_t reserved[4];
};

static void CallGamePacketHandler(uintptr_t handler, const Packet* pkt)
{
    if (!handler || !pkt || !pkt->data) {
        return;
    }
    NewGamePacket game {};
    game.length = pkt->length;
    game.bitSize = pkt->bitSize;
    game.data = pkt->data;
    reinterpret_cast<void(*)(NewGamePacket*)>(handler)(&game);
}

size_t BoundedStringLength(const char* value, size_t capacity)
{
    if (!value) {
        return 0;
    }

    size_t length = 0;
    while (length < capacity && value[length] != '\0') {
        ++length;
    }
    return length;
}

inline CRemotePlayer* GetRemotePlayerForSync(uint16_t playerId)
{
    if (playerId >= kPlayerPoolSize) {
        return nullptr;
    }

    CPlayerPool* pool = CNetGame::GetPlayerPool();
    if (!pool) {
        return nullptr;
    }

    return pool->GetAt(playerId);
}
}

bool CNetGame::QueueDialogResponse(RakNet::BitStream& response)
{
    const bool accepted = QueueGuiMessage(10, reinterpret_cast<const char*>(response.GetData()),
                                          response.GetNumberOfBytesUsed());
    return accepted;
}

bool CNetGame::QueueJsonData(int guiId, const char* data, uint32_t length)
{
    return guiId != 10 && QueueGuiMessage(guiId, data, length);
}

void CNetGame::ResetGuiSession(bool active)
{
    pthread_mutex_lock(&gPendingGuiMutex);
    for (PendingGuiMessage& slot : gPendingGuiMessages) {
        delete[] slot.data;
        slot = PendingGuiMessage {};
    }
    gPendingGuiRead = gPendingGuiWrite = gPendingGuiCount = 0;
    gGuiSessionActive = active;
    pthread_mutex_unlock(&gPendingGuiMutex);
}

bool CNetGame::SetServerEndpoint(const char* host, uint16_t port)
{
    if (!StoreServerEndpoint(host, port)) {
        return false;
    }

    return true;
}

uint8_t GetPacketID(Packet *p)
{
	if(p == 0 || !p->data || p->length == 0) { return 255; }
	if ((uint8_t)p->data[0] == ID_TIMESTAMP) {
		if (p->length <= sizeof(uint8_t) + sizeof(RakNetTime)) {
			return 255;
		}
		return (uint8_t)p->data[sizeof(uint8_t) + sizeof(RakNetTime)];
	} else {
		return (uint8_t)p->data[0];
	}
}

static bool ReadSyncPacketHeader(RakNet::BitStream& bsData, const Packet* pkt, uint8_t& pktId, uint16_t& playerId)
{
    if (!pkt || !pkt->data || pkt->length == 0) {
        return false;
    }

    if (pkt->data[0] == ID_TIMESTAMP) {
        uint8_t timestampId = 0;
        RakNetTime timestamp = 0;
        if (!bsData.ReadBits(reinterpret_cast<unsigned char*>(&timestampId), 8)) {
            return false;
        }
        if (!bsData.ReadBits(reinterpret_cast<unsigned char*>(&timestamp), sizeof(RakNetTime) * 8)) {
            return false;
        }
    }

    return bsData.ReadBits(reinterpret_cast<unsigned char*>(&pktId), 8) &&
           bsData.ReadBits(reinterpret_cast<unsigned char*>(&playerId), 16);
}

CPlayerPool* CNetGame::GetPlayerPool()
{
    static uintptr_t addr = 0;
    if (!LAIRD_GAME_ADDRESS(addr, "CNetGame::m_pPlayerPool")) {
        return nullptr;
    }
    return *(CPlayerPool **)(addr);
}

void CNetGame::ProcessNetwork()
{
	Packet* pkt = nullptr;
	uint8_t packetIdentifier;
    uint32_t processedPackets = 0;
	while((pkt = pRakClient->Receive()) != nullptr)
	{
		packetIdentifier = GetPacketID(pkt);
		switch(packetIdentifier)
		{
			case ID_FAILED_INITIALIZE_ENCRIPTION:
				CChat::AddDebugMessage(xorstr("Failed to initialize encryption."));
				break;
			case ID_CONNECTION_ATTEMPT_FAILED:
				CChat::AddDebugMessage(xorstr("Сервер не отвечает."));
				ScheduleReconnect();
				break;
			case ID_NO_FREE_INCOMING_CONNECTIONS:
				CChat::AddDebugMessage(xorstr("Сервер полон."));
				ScheduleReconnect();
				break;
			case ID_CONNECTION_BANNED:
                ResetGuiSession();
				CancelReconnect();
				SetGameState(GAMESTATE_DISCONNECTED);
				CChat::AddDebugMessage(xorstr("Вы были заблокированы на этом сервере."));
				break;
			case ID_INVALID_PASSWORD:
                ResetGuiSession();
                CancelReconnect();
                SetGameState(GAMESTATE_DISCONNECTED);
				CChat::AddDebugMessage(xorstr("Wrong server password."));
				pRakClient->Disconnect(0);
				break;
			case ID_AUTH_KEY:
				// Black Russia reuses packet id 12 for turn-light sync after login.
				// Authentication packets are longer; a turn-light packet is exactly 4 bytes.
				if (GetGameState() == GAMESTATE_CONNECTED && pkt && pkt->length == 4) {
					Packet_TurnLightsSync(pkt);
				} else {
					Packet_AuthKey(pkt);
				}
				break;
			case ID_CONNECTION_REQUEST_ACCEPTED:
				CancelReconnect();
				Packet_ConnectionSucceeded(pkt);
				break;
			case ID_CONNECTION_LOST:
				Packet_ConnectionLost(pkt);
				break;
			case ID_DISCONNECTION_NOTIFICATION:
				ScheduleReconnect();
				break;
				




			case ID_TRAILER_SYNC:
				Packet_TrailerSync(pkt);
				break;

			
			case 252: 
			{
		       Packet_GUI(pkt);
   			 break;
			}
		}

		pRakClient->DeallocatePacket(pkt);

        if (++processedPackets >= kMaxPacketsPerProcessTick) {
            break;
        }
	}

	// Сначала удаляем старые disconnect/failure пакеты, и только потом
	// запускаем новую попытку. Иначе старое событие отменяло свежий Connect.
	ProcessReconnectTimer();
    FlushQueuedGuiMessages();
}

int CNetGame::GetGameState()
{
    static uintptr_t addr = 0;
    if (!LAIRD_GAME_ADDRESS(addr, "CNetGame::m_iGameState")) {
        return GAMESTATE_NONE;
    }
	return *(int *)(addr);
}

void CNetGame::SetGameState(int state)
{
    static uintptr_t addr = 0;
    if (!LAIRD_GAME_ADDRESS(addr, "CNetGame::m_iGameState")) {
        return;
    }
	*(int *)(addr) = state;
}


extern char AuthKeyTable[512][2][128];
void CNetGame::Packet_AuthKey(Packet* pkt)
{
    if (!pkt || !pkt->data || pkt->length < 2 || !pRakClient) {
        return;
    }

    size_t idOffset = 0;
    if (pkt->data[0] == ID_TIMESTAMP) {
        idOffset = 1u + sizeof(RakNetTime);
    }
    if (pkt->length < idOffset + 2u ||
        pkt->data[idOffset] != static_cast<unsigned char>(ID_AUTH_KEY)) {
        return;
    }

    const uint8_t packetAuthLength = pkt->data[idOffset + 1u];
    const size_t authOffset = idOffset + 2u;
    if (packetAuthLength == 0 ||
        packetAuthLength > sizeof(AuthKeyTable[0][0]) ||
        pkt->length < authOffset + static_cast<unsigned int>(packetAuthLength)) {
        return;
    }

    char incomingAuth[sizeof(AuthKeyTable[0][0]) + 1] = {};
    std::memcpy(incomingAuth, pkt->data + authOffset, packetAuthLength);
    incomingAuth[packetAuthLength] = '\0';
    const size_t incomingAuthLength = BoundedStringLength(incomingAuth, packetAuthLength);

    const char* authKey = nullptr;
    for (int index = 0; index < 512; ++index) {
        const size_t tableKeyLength = BoundedStringLength(
            AuthKeyTable[index][0], sizeof(AuthKeyTable[index][0]));
        if (tableKeyLength == incomingAuthLength &&
            std::memcmp(incomingAuth, AuthKeyTable[index][0], incomingAuthLength) == 0) {
            authKey = AuthKeyTable[index][1];
            break;
        }
    }

    if (!authKey) {
        return;
    }

    const size_t authKeyLength = BoundedStringLength(authKey, sizeof(AuthKeyTable[0][1]));
    if (authKeyLength == 0 || authKeyLength > sizeof(AuthKeyTable[0][1]) || authKeyLength > 255) {
        return;
    }

    RakNet::BitStream bsKey;
    const uint8_t byteAuthKeyLen = static_cast<uint8_t>(authKeyLength);
    bsKey.Write(static_cast<uint8_t>(ID_AUTH_KEY));
    bsKey.Write(byteAuthKeyLen);
    bsKey.Write(authKey, byteAuthKeyLen);
    pRakClient->Send(&bsKey, SYSTEM_PRIORITY, RELIABLE, 0);
}

void CNetGame::Packet_ConnectionLost(Packet* pkt)
{
	/*
	 * The original ARM64 function at 0x4AC314 is a CNetGame member method.
	 * Calling it as void(*)() leaves x0 without a valid `this` pointer and
	 * eventually branches into a non-executable part of the client library.
	 * Handle the disconnect through RakClient and the public game state instead.
	 */
	ScheduleReconnect();
}

void CNetGame::Packet_TurnLightsSync(Packet* pkt)
{
	constexpr uint16_t kMaxVehicleId = 1999;

	if (!pkt || !pkt->data || pkt->length != 4) {
		return;
	}

	RakNet::BitStream bs(pkt->data, pkt->length, false);
	uint8_t packetId = 0;
	uint16_t vehicleId = 0;
	uint8_t status = 0;
	if (!bs.Read(packetId) || !bs.Read(vehicleId) || !bs.Read(status) ||
		packetId != ID_AUTH_KEY || vehicleId == 0 || vehicleId > kMaxVehicleId || status > 3) {
		return;
	}

	static uintptr_t handler = 0;
	LAIRD_GAME_ADDRESS(handler, "CNetGame::Packet_TurnLightsSync");
	if (!handler) {
		return;
	}

	CallGamePacketHandler(handler, pkt);
}

// SA-MP relays a towing player's trailer as packet 210; the game reads the same 54 bytes as its packet 6.
void CNetGame::Packet_TrailerSync(Packet* pkt)
{
	constexpr unsigned int kSyncBytes = 54;
	constexpr uint16_t kMaxVehicleId = 1999;

	if (GetGameState() != GAMESTATE_CONNECTED || !pkt || !pkt->data || pkt->length == 0) {
		return;
	}

	RakNet::BitStream bs(pkt->data, pkt->length, false);
	uint8_t packetId = 0;
	uint16_t playerId = 0;
	if (!ReadSyncPacketHeader(bs, pkt, packetId, playerId) || packetId != ID_TRAILER_SYNC ||
		playerId >= kPlayerPoolSize || bs.GetNumberOfUnreadBits() < static_cast<int>(kSyncBytes * 8)) {
		return;
	}

	unsigned char game[3 + kSyncBytes] = {};
	game[0] = BR_ID_TRAILER_SYNC;
	std::memcpy(game + 1, &playerId, sizeof(playerId));
	if (!bs.ReadBits(game + 3, kSyncBytes * 8)) {
		return;
	}

	uint16_t trailerId = 0;
	float values[13] = {};
	std::memcpy(&trailerId, game + 3, sizeof(trailerId));
	std::memcpy(values, game + 5, sizeof(values));
	if (trailerId == 0 || trailerId > kMaxVehicleId) {
		return;
	}
	for (float value : values) {
		if (!std::isfinite(value)) {
			return;
		}
	}
	if (!GetRemotePlayerForSync(playerId)) {
		return;
	}

	static uintptr_t handler = 0;
	LAIRD_GAME_ADDRESS(handler, "CNetGame::Packet_TrailerSync");
	if (!handler) {
		return;
	}

	Packet converted = *pkt;
	converted.data = game;
	converted.length = sizeof(game);
	converted.bitSize = sizeof(game) * 8;
	converted.deleteData = false;
	CallGamePacketHandler(handler, &converted);
}

void CNetGame::Packet_ConnectionSucceeded(Packet* pkt)
{
	if (!pkt || !pkt->data || pkt->length == 0 || !pRakClient) {
		return;
	}

	RakNet::BitStream bsSuccAuth((unsigned char *)pkt->data, pkt->length, false);
	uint8_t packetId = 0;
	if (!bsSuccAuth.Read(packetId)) {
		return;
	}

	if (packetId == ID_TIMESTAMP) {
		RakNetTime timestamp = 0;
		if (!bsSuccAuth.Read(timestamp) || !bsSuccAuth.Read(packetId)) {
			return;
		}
	}

	if (packetId != ID_CONNECTION_REQUEST_ACCEPTED) {
		return;
	}

	uint32_t binaryAddress = 0;
	uint16_t port = 0;
	uint16_t MyPlayerID = 0;
	uint32_t uiChallenge = 0;
	if (!bsSuccAuth.Read(binaryAddress) ||
		!bsSuccAuth.Read(port) ||
		!bsSuccAuth.Read(MyPlayerID) ||
		!bsSuccAuth.Read(uiChallenge) ||
		MyPlayerID >= kPlayerPoolSize) {
		return;
	}

    CPlayerPool* pool = GetPlayerPool();
    if (!pool) {
        return;
    }
    CLocalPlayer* localPlayer = pool->GetLocalPlayer();
    if (!localPlayer) {
        return;
    }

	localPlayer->SetLocalPlayerID(MyPlayerID);

	int iVersion = NETGAME_VERSION;
	char byteMod = 0x01;
	unsigned int uiClientChallengeResponse = uiChallenge ^ iVersion;

	const char* sampVersion = xorstr("0.3.7");
	const char* auth_bs = xorstr("15121F6F18550C00AC4B4F8A167D0379BB0ACA99043");
	
	const char* localPlayerName = reinterpret_cast<const char*>(localPlayer->GetLocalPlayerName());
    if (!localPlayerName) {
        return;
    }
	size_t localPlayerNameLength = BoundedStringLength(localPlayerName, 25);
	if (localPlayerNameLength > 24) {
		return;
	}
	static char fallbackName[25];
	if (localPlayerNameLength < 3) {
		snprintf(fallbackName, sizeof(fallbackName), "Laird_Test%u", static_cast<unsigned int>(MyPlayerID));
		localPlayerName = fallbackName;
		localPlayerNameLength = std::strlen(fallbackName);
	}
	
	const uint8_t byteAuthBSLen = static_cast<uint8_t>(std::strlen(auth_bs));
	const uint8_t byteNameLen = static_cast<uint8_t>(localPlayerNameLength);
	const uint8_t byteClientverLen = static_cast<uint8_t>(std::strlen(sampVersion));

	RakNet::BitStream bsSend;
	bsSend.Write(iVersion);
	bsSend.Write(byteMod);
	bsSend.Write(byteNameLen);
	bsSend.Write(localPlayerName, byteNameLen);
	bsSend.Write(uiClientChallengeResponse);
	bsSend.Write(byteAuthBSLen);
	bsSend.Write(auth_bs, byteAuthBSLen);
	bsSend.Write(byteClientverLen);
	bsSend.Write(sampVersion, byteClientverLen);
	if (!pRakClient->RPC(&RPC_ClientJoin, &bsSend, HIGH_PRIORITY, RELIABLE, 0,
		false, UNASSIGNED_NETWORK_ID, nullptr)) {
		return;
	}
	
	SetGameState(GAMESTATE_AWAIT_JOIN);
    ResetGuiSession(true);
}

bool CNetGame::SendJsonData(int guiId, const char* data, uint32_t length)
{
	if (!pRakClient || guiId < 0 || guiId > 0xFFFF ||
		length > kMaxGuiPayloadSize || (!data && length != 0)) {
		return false;
	}

    RakNet::BitStream bsSend;
    bsSend.Write((uint8_t)252);
    bsSend.Write((uint16_t)guiId);
    bsSend.Write((uint32_t)length);
    if (length != 0) {
        bsSend.Write(data, length);
    }

    return pRakClient->Send(&bsSend, SYSTEM_PRIORITY, RELIABLE_ORDERED, 0);
}

extern "C" JNIEXPORT void JNICALL Java_com_blackhub_bronline_game_core_JNIJSONTransport_sendJsonData(
    JNIEnv* env, jclass clazz, jint guiId, jbyteArray data)
{
    (void)clazz;

    if (!env || !data || guiId == 10 || guiId < 0 || guiId > 0xFFFF)
        return;

    jsize length = env->GetArrayLength(data);
    if (env->ExceptionCheck() || length < 0 ||
        static_cast<uint32_t>(length) > kMaxGuiPayloadSize) {
        return;
    }

    if (length == 0) {
        CNetGame::QueueJsonData(guiId, nullptr, 0);
        return;
    }

    jbyte* byteArray = env->GetByteArrayElements(data, nullptr);
    if (!byteArray) {
        return;
    }

    CNetGame::QueueJsonData(
        guiId, reinterpret_cast<const char*>(byteArray), static_cast<uint32_t>(length));
    env->ReleaseByteArrayElements(data, byteArray, JNI_ABORT);
}


void CNetGame::Packet_GUI(Packet* pkt)
{
	if (!pkt || !pkt->data || pkt->length == 0) {
		return;
	}

	RakNet::BitStream bsData(pkt->data, pkt->length, false);
	uint8_t packetId = 0;
	if (!bsData.Read(packetId)) {
		return;
	}

	if (packetId == ID_TIMESTAMP) {
		RakNetTime timestamp = 0;
		if (!bsData.Read(timestamp) || !bsData.Read(packetId)) {
			return;
		}
	}

	if (packetId != 252) {
		return;
	}

	uint16_t guiId = 0;
	uint32_t payloadLength = 0;
	if (!bsData.Read(guiId) || !bsData.Read(payloadLength)) {
		return;
	}

	const int unreadBits = bsData.GetNumberOfUnreadBits();
	if (payloadLength > kMaxGuiPayloadSize || unreadBits < 0 ||
		static_cast<uint32_t>(unreadBits) < payloadLength * 8u) {
		return;
	}

	static uintptr_t handler = 0;
	LAIRD_GAME_ADDRESS(handler, "CNetGame::Packet_GUI");
	if (!handler) {
		return;
	}

	CallGamePacketHandler(handler, pkt);
}
