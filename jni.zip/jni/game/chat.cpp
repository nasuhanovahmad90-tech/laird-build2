// LAIRD ULTRA launcher (Black Russia client) — by laird

#include "chat.h"
#include "xorstr.h"

#include "plugin.h"

void CChat::AddDebugMessage(const char* msg, ...) {
    // Resolved once; the game function is printf-like, so the finished text goes as "%s" (a '%' in it
    // used to be read as a format directive).
    static uintptr_t function = 0;
    if (!function) function = CGameAPI::GetBase(xorstr("CChat::AddDebugMessage"));
    if (!function || !msg) return;

    char buffer[1024];
    va_list args;
    va_start(args, msg);
    vsnprintf(buffer, sizeof(buffer), msg, args);
    va_end(args);

    reinterpret_cast<void(*)(const char*, ...)>(function)("%s", buffer);
}
