// LAIRD ULTRA launcher (Black Russia client) — by laird

#include "hooks.h"
#include "../client_config.h"
#include "xorstr.h"
#include "plugin/netrpc.h"
#include "game/chat.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <new>
#include <string>
#include <unordered_set>
#include <vector>

extern bool g_bInitGameProcess;

RakClientInterface* pRakClient = RakNetworkFactory::GetRakClientInterface();


void (*orig_CNetGame__ProcessNetwork)();
void hook_CNetGame__ProcessNetwork()
{
    CNetGame::ProcessNetwork();
}

void (*orig_CChat__AddDebugMessage)(const char* format, ...);
void hook_CChat__AddDebugMessage(const char* format, ...)
{
    if(!orig_CChat__AddDebugMessage) {
        return;
    }
    if(!format) {
        orig_CChat__AddDebugMessage("%s", "");
        return;
    }

    char formatted[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(formatted, sizeof(formatted), format, args);
    va_end(args);

    std::string text = formatted;
    for (const char* name : {"BLACK RUSSIA"}) {
        const std::string from = name;
        size_t pos = 0;
        while ((pos = text.find(from, pos)) != std::string::npos) {
            text.replace(pos, from.length(), ClientConfig::ServerName);
            pos += std::strlen(ClientConfig::ServerName);
        }
    }

    orig_CChat__AddDebugMessage("%s", text.c_str());
}

bool (*orig_RakClient__Connect)(uintptr_t thiz, const char* host, uint16_t serverPort, uint16_t clientPort, int depreciated, const char* password);
bool hook_RakClient__Connect(uintptr_t thiz, const char* host, uint16_t serverPort, uint16_t clientPort, int depreciated, const char* password)
{
    if (!pRakClient) {
        return false;
    }
    CNetGame::ResetGuiSession();
    CNetGame::SetServerEndpoint(ClientConfig::ServerHost, ClientConfig::ServerPort);
    return pRakClient->Connect(ClientConfig::ServerHost, ClientConfig::ServerPort, 0, 0, 5);
}

static size_t Utf8ToCp1251(const unsigned char* in, size_t length, char* out, size_t capacity)
{
    size_t o = 0;
    for (size_t i = 0; i < length && o + 1 < capacity;) {
        uint32_t c = in[i];
        size_t extra = c < 0x80 ? 0 : (c & 0xE0) == 0xC0 ? 1 : (c & 0xF0) == 0xE0 ? 2 : (c & 0xF8) == 0xF0 ? 3 : 0;
        if (c >= 0x80 && extra == 0) { ++i; out[o++] = '?'; continue; }
        if (extra) {
            if (i + extra >= length) break;
            c &= (0x3F >> extra);
            for (size_t k = 1; k <= extra; ++k) c = (c << 6) | (in[i + k] & 0x3F);
        }
        i += extra + 1;
        char b = '?';
        if (c < 0x80) b = static_cast<char>(c);
        else if (c >= 0x410 && c <= 0x44F) b = static_cast<char>(0xC0 + (c - 0x410));
        else if (c == 0x401) b = static_cast<char>(0xA8);
        else if (c == 0x451) b = static_cast<char>(0xB8);
        else if (c == 0x2116) b = static_cast<char>(0xB9);
        else if (c == 0xAB) b = static_cast<char>(0xAB);
        else if (c == 0xBB) b = static_cast<char>(0xBB);
        else if (c == 0x2014 || c == 0x2013) b = '-';
        out[o++] = b;
    }
    out[o] = '\0';
    return o;
}

static bool RecodeOutgoingText(RakNet::BitStream* bitStream, bool wideLength, RakNet::BitStream& out)
{
    RakNet::BitStream in(bitStream->GetData(), bitStream->GetNumberOfBytesUsed(), false);
    uint32_t length = 0;
    if (wideLength) {
        if (!in.Read(length)) return false;
    } else {
        uint8_t shortLength = 0;
        if (!in.Read(shortLength)) return false;
        length = shortLength;
    }
    static unsigned char text[1025];
    static char converted[1025];
    if (length > 1024u || !in.Read(reinterpret_cast<char*>(text), static_cast<int>(length))) return false;
    const size_t outLength = Utf8ToCp1251(text, length, converted, sizeof(converted));
    if (wideLength) out.Write(static_cast<uint32_t>(outLength));
    else out.Write(static_cast<uint8_t>(outLength > 255 ? 255 : outLength));
    out.Write(converted, static_cast<int>(wideLength || outLength <= 255 ? outLength : 255));
    return true;
}

bool (*orig_RakClient__RPC)( uintptr_t thiz, int uniqueID, RakNet::BitStream *bitStream, PacketPriority priority, BRPacketReliability reliability, char orderingChannel );
bool hook_RakClient__RPC( uintptr_t thiz, int uniqueID, RakNet::BitStream *bitStream, PacketPriority priority, BRPacketReliability reliability, char orderingChannel )
{
    if (!pRakClient) {
        return false;
    }

    int sampRpcId = ConvertBRIDToSampID(static_cast<BRRpcIds>(uniqueID));

    if(uniqueID == BR_RPC_ClientInfo) {
        sampRpcId = 97; 
    }
    if(sampRpcId == -1) {
        static unsigned int logged = 0;
        if (logged < 64u) {
            ++logged;
        }
    }
    

    
    if(sampRpcId != -1) {
        if(sampRpcId == RPC_RequestClass && g_bInitGameProcess) {
            return false;
        }
        
        if ((sampRpcId == RPC_Chat || sampRpcId == RPC_ServerCommand) && bitStream) {
            RakNet::BitStream converted;
            if (RecodeOutgoingText(bitStream, sampRpcId == RPC_ServerCommand, converted)) {
                return pRakClient->RPC(&sampRpcId, &converted, priority, ConvertBRToSampReliability(reliability), orderingChannel, false, UNASSIGNED_NETWORK_ID, nullptr);
            }
        }
        return pRakClient->RPC(&sampRpcId, bitStream, priority, ConvertBRToSampReliability(reliability), orderingChannel, false, UNASSIGNED_NETWORK_ID, nullptr);
    }
    
    return false;
}

// Поворотники идут не пакетом, а кнопкой: RPC 313 -> 97 (действие 3), см. hook_RakClient__RPC.
bool (*orig_RakClient__Send)( uintptr_t thiz, RakNet::BitStream* bitStream, PacketPriority priority, BRPacketReliability reliability, char orderingChannel );
bool hook_RakClient__Send( uintptr_t thiz, RakNet::BitStream* bitStream, PacketPriority priority, BRPacketReliability reliability, char orderingChannel )
{
    if (!pRakClient || !bitStream) {
        return false;
    }

    const unsigned int bytesUsed = bitStream->GetNumberOfBytesUsed();
    const int bitsUsed = bitStream->GetNumberOfBitsUsed();
    const unsigned char* streamData = bitStream->GetData();
    if (!streamData || bytesUsed == 0 || bitsUsed <= 0) {
        return false;
    }

    RakNet::BitStream bsCopy(const_cast<unsigned char*>(streamData), bytesUsed, false);
    bsCopy.SetWriteOffset(bitsUsed);

    uint8_t pktId = 0;
    if (!bsCopy.Read(pktId)) {
        return false;
    }

    if(pktId == BR_ID_USER_INTERFACE_SYNC) {
        uint16_t guiId = 0;
        uint32_t jsonLen = 0;
        if (!bsCopy.Read(guiId) || !bsCopy.Read(jsonLen)) {
            return false;
        }

        if (jsonLen == 0) {
            return guiId != 10 && CNetGame::QueueJsonData(guiId, nullptr, 0);
        }
        if(jsonLen > 0) {
            bool queued = false;
            const uint32_t kMaxJsonSize = 1u << 20;
            if (jsonLen > kMaxJsonSize) {
                return false;
            }

            char* buff = new (std::nothrow) char[jsonLen + 1];
            if (!buff) {
                return false;
            }
            if (!bsCopy.Read(buff, jsonLen)) {
                delete[] buff;
                return false;
            }
            buff[jsonLen] = '\0';


            if(guiId == 10) {
                size_t utfCap = static_cast<size_t>(jsonLen) * 3 + 1;
                char* buffGUI = new (std::nothrow) char[utfCap];
                if (!buffGUI) {
                    delete[] buff;
                    return false;
                }
                cp1251_to_utf8(buffGUI, buff, jsonLen);

                const char* dialogJson = nullptr;
                if (nlohmann::json::accept(buff)) {
                    dialogJson = buff;
                } else if (nlohmann::json::accept(buffGUI)) {
                    dialogJson = buffGUI;
                }

                if (dialogJson) {
                    nlohmann::json jsonObj = nlohmann::json::parse(dialogJson, nullptr, false);
                    if (!jsonObj.is_discarded() && jsonObj.is_object()) {
                        const auto btnIt = jsonObj.find("r");
                        const auto listIt = jsonObj.find("l");
                        const auto inputIt = jsonObj.find("i");

                        if (btnIt != jsonObj.end() && btnIt->is_number_integer() &&
                            listIt != jsonObj.end() && listIt->is_number_integer() &&
                            inputIt != jsonObj.end() && inputIt->is_string()) {
                            const int64_t btnValue = btnIt->get<int64_t>();
                            const int64_t listValue = listIt->get<int64_t>();
                            const std::string& input = inputIt->get_ref<const std::string&>();

                            if (btnValue >= 0 && btnValue <= 255 &&
                                listValue >= -32768 && listValue <= 32767 &&
                                input.size() <= 255) {
                                const uint8_t btn = static_cast<uint8_t>(btnValue);
                                const int16_t listInput = static_cast<int16_t>(listValue);
                                const uint8_t inputLen = static_cast<uint8_t>(input.size());
                                RakNet::BitStream bsSend;
                                const uint16_t dialogId = CNetGame::m_nLastSAMPDialogID.load();
                                bsSend.WriteBits((const unsigned char *)&dialogId, 16);
                                bsSend.WriteBits((const unsigned char *)&btn, 8);
                                bsSend.WriteBits((const unsigned char *)&listInput, 16);
                                bsSend.WriteBits((const unsigned char *)&inputLen, 8);
                                bsSend.Write(input.c_str(), inputLen);
                                queued = CNetGame::QueueDialogResponse(bsSend);
                            }
                        }
                    }
                }
                delete[] buffGUI;
            } else {
                // For pawn-json payloads preserve original bytes to avoid UTF-8/CP1251 double conversion.
                const bool queued = CNetGame::QueueJsonData(guiId, buff, jsonLen);
                delete[] buff;
                return queued;
            }
            delete[] buff;
            return queued;
        }
    }
	if(pktId == BR_ID_AIM_SYNC) {
		uint8_t pktAimSync = ID_AIM_SYNC;
	    uint8_t aimSyncBuffer[31] = {0};
		if (!bsCopy.ReadBits(aimSyncBuffer, 31 * 8)) {
			return false;
		}
		RakNet::BitStream bsSend;
	    bsSend.WriteBits(&pktAimSync, 8);
	    bsSend.WriteBits(aimSyncBuffer, 31 * 8);
	    return pRakClient->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
	}
	if(pktId == BR_ID_BULLET_SYNC) {
		uint8_t pktBltSync = ID_BULLET_SYNC;
	    uint8_t bltSyncBuffer[40] = {0};
		if (!bsCopy.ReadBits(bltSyncBuffer, 40 * 8)) {
			return false;
		}
		RakNet::BitStream bsSend;
	    bsSend.WriteBits(&pktBltSync, 8);
	    bsSend.WriteBits(bltSyncBuffer, 40 * 8);
	    return pRakClient->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
	}
	if(pktId == BR_ID_PLAYER_SYNC) {
		uint8_t pktPlayerSync = ID_PLAYER_SYNC;
	    BROnFootSyncData data = {};
	    if (!bsCopy.ReadBits((unsigned char *)&data.lrAnalogLeftStick, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.udAnalogLeftStick, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.wKeys, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecPos, 96) ||
			!bsCopy.ReadBits((unsigned char *)&data.quatw, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.quatx, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.quaty, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.quatz, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.health, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.armour, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.byteCurrentWeapon, 8) ||
			!bsCopy.ReadBits((unsigned char *)&data.byteSpecialAction, 8) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecMoveSpeed, 96) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecSurfOffsets, 96) ||
			!bsCopy.ReadBits((unsigned char *)&data.wSurfInfo, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.dwAnimation, 32)) {
			return false;
		}
	    RakNet::BitStream bsSend;
	    bsSend.WriteBits(&pktPlayerSync, 8);
	    ConvertBROnFootSyncToSampSync(&bsSend, data);
	    return pRakClient->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
	}
	if(pktId == BR_ID_VEHICLE_SYNC) {
		uint8_t pktVehicleSync = ID_VEHICLE_SYNC;
	    BRInCarSyncData data = {};
	    if (!bsCopy.ReadBits((unsigned char *)&data.VehicleID, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.lrAnalogLeftStick, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.udAnalogLeftStick, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.wKeys, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.quatw, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.quatx, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.quaty, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.quatz, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecPos.x, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecPos.y, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecPos.z, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecMoveSpeed.x, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecMoveSpeed.y, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecMoveSpeed.z, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.fCarHealth, 32) ||
			!bsCopy.ReadBits((unsigned char *)&data.playerHealth, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.playerArmour, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.byteCurrentWeapon, 8) ||
			!bsCopy.ReadBits((unsigned char *)&data.byteSirenOn, 8) ||
			!bsCopy.ReadBits((unsigned char *)&data.byteLandingGearState, 8) ||
			!bsCopy.ReadBits((unsigned char *)&data.TrailerID, 16)) {
			return false;
		}
		static float lastHealth[2000] = {0};
    	if(data.VehicleID < 2000) {
			if(lastHealth[data.VehicleID] != data.fCarHealth) {
				lastHealth[data.VehicleID] = data.fCarHealth;
			}
    	}

    RakNet::BitStream bsSend;
    bsSend.WriteBits(&pktVehicleSync, 8);
    ConvertBRInCarSyncToSampSync(&bsSend, data);
    return pRakClient->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
}
	if(pktId == BR_ID_PASSENGER_SYNC) {
		uint8_t pktPassengerSync = ID_PASSENGER_SYNC;
		BRPassengerSyncData data = {};
		if (!bsCopy.ReadBits((unsigned char *)&data.VehicleID, 16)) {
			return false;
		}
		uint8_t seatAndDriveBy = 0;
		if (!bsCopy.ReadBits((unsigned char *)&seatAndDriveBy, 8)) {
			return false;
		}
		data.byteSeatFlags = (seatAndDriveBy & 0x7F);
		data.byteDriveBy = ((seatAndDriveBy >> 7) & 0x01);
		if (!bsCopy.ReadBits((unsigned char *)&data.byteCurrentWeapon, 8) ||
			!bsCopy.ReadBits((unsigned char *)&data.playerHealth, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.playerArmour, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.lrAnalog, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.udAnalog, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.wKeys, 16) ||
			!bsCopy.ReadBits((unsigned char *)&data.vecPos, 96)) {
			return false;
		}
		RakNet::BitStream bsSend;
	    bsSend.WriteBits(&pktPassengerSync, 8);
	    ConvertBRPassengerSyncToSampSync(&bsSend, data);
	    return pRakClient->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
	}
	if(pktId == BR_ID_UNOCCUPIED_SYNC) {
		constexpr unsigned int kPacketBytes = 68;
		constexpr int kPacketBits = kPacketBytes * 8;
		constexpr uint16_t kMaxVehicleId = 1999;
		if (bytesUsed != kPacketBytes || bitsUsed != kPacketBits) {
			return false;
		}

		BRUnoccupiedSyncData data = {};
		if (!bsCopy.Read(data.VehicleID) || !bsCopy.Read(data.byteSeatID) ||
			!bsCopy.Read(data.vecRoll.x) || !bsCopy.Read(data.vecRoll.y) || !bsCopy.Read(data.vecRoll.z) ||
			!bsCopy.Read(data.vecDirection.x) || !bsCopy.Read(data.vecDirection.y) || !bsCopy.Read(data.vecDirection.z) ||
			!bsCopy.Read(data.vecPos.x) || !bsCopy.Read(data.vecPos.y) || !bsCopy.Read(data.vecPos.z) ||
			!bsCopy.Read(data.vecMoveSpeed.x) || !bsCopy.Read(data.vecMoveSpeed.y) || !bsCopy.Read(data.vecMoveSpeed.z) ||
			!bsCopy.Read(data.vecTurnSpeed.x) || !bsCopy.Read(data.vecTurnSpeed.y) || !bsCopy.Read(data.vecTurnSpeed.z) ||
			!bsCopy.Read(data.fHealth)) {
			return false;
		}

		const auto finiteVector = [](const CVector& vec) {
			return std::isfinite(vec.x) && std::isfinite(vec.y) && std::isfinite(vec.z);
		};
		if (data.VehicleID == 0 || data.VehicleID > kMaxVehicleId || data.byteSeatID > 7 ||
			!finiteVector(data.vecRoll) || !finiteVector(data.vecDirection) ||
			!finiteVector(data.vecPos) || !finiteVector(data.vecMoveSpeed) ||
			!finiteVector(data.vecTurnSpeed) || !std::isfinite(data.fHealth)) {
			return false;
		}

		const uint8_t packetId = ID_UNOCCUPIED_SYNC;
		RakNet::BitStream bsSend;
		bsSend.Write(packetId);
		bsSend.Write(data.VehicleID);
		bsSend.Write(data.byteSeatID);
		bsSend.Write(data.vecRoll.x); bsSend.Write(data.vecRoll.y); bsSend.Write(data.vecRoll.z);
		bsSend.Write(data.vecDirection.x); bsSend.Write(data.vecDirection.y); bsSend.Write(data.vecDirection.z);
		bsSend.Write(data.vecPos.x); bsSend.Write(data.vecPos.y); bsSend.Write(data.vecPos.z);
		bsSend.Write(data.vecMoveSpeed.x); bsSend.Write(data.vecMoveSpeed.y); bsSend.Write(data.vecMoveSpeed.z);
		bsSend.Write(data.vecTurnSpeed.x); bsSend.Write(data.vecTurnSpeed.y); bsSend.Write(data.vecTurnSpeed.z);
		bsSend.Write(data.fHealth);
		return pRakClient->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
	}
	// The game builds these three exactly like SA-MP 0.3.7, only the packet id differs:
	// trailer = u16 id, pos, quat, speed, turn speed (54 bytes); spectator = lr, ud, keys, pos (18 bytes);
	// weapons = u16 target player, u16 target actor, then u8 slot, u8 weapon, u16 ammo per slot.
	if(pktId == BR_ID_TRAILER_SYNC || pktId == BR_ID_SPECTATOR_SYNC || pktId == BR_ID_WEAPONS_UPDATE) {
		const unsigned int payload = bytesUsed - 1;
		uint8_t sampId = ID_TRAILER_SYNC;
		bool valid = bitsUsed == static_cast<int>(bytesUsed * 8);
		if(pktId == BR_ID_TRAILER_SYNC) {
			valid = valid && payload == 54;
		} else if(pktId == BR_ID_SPECTATOR_SYNC) {
			sampId = ID_SPECTATOR_SYNC;
			valid = valid && payload == 18;
		} else {
			sampId = ID_WEAPONS_UPDATE;
			valid = valid && payload >= 4 && (payload - 4) % 4 == 0 && (payload - 4) / 4 <= 13;
		}
		if(!valid) {
			return false;
		}
		if(pktId == BR_ID_TRAILER_SYNC) {
			float values[13] = {};
			std::memcpy(values, streamData + 3, sizeof(values));
			for(float value : values) {
				if(!std::isfinite(value)) return false;
			}
		}
		RakNet::BitStream bsSend;
		bsSend.Write(sampId);
		bsSend.Write(reinterpret_cast<const char*>(streamData + 1), payload);
		return pRakClient->Send(&bsSend, HIGH_PRIORITY,
			pktId == BR_ID_WEAPONS_UPDATE ? RELIABLE : UNRELIABLE_SEQUENCED, 0);
	}

	static uint8_t reported[256] = {};
	if (!reported[pktId]) {
		reported[pktId] = 1;
	}
	return false;
}
