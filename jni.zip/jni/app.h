// LAIRD ULTRA launcher (Black Russia client) — by laird
#pragma once

enum eAppInit
{
	APP_INIT_OFFSETS,
	APP_INIT_RW,
};


// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
// by laird
class CApp
{
public:
	static void Initialise(eAppInit init_type);
};
