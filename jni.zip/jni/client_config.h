// LAIRD ULTRA launcher (Black Russia client) — by laird
#pragma once
#include <cstdint>

namespace ClientConfig
{
    inline constexpr char ServerHost[] = "178.130.53.60";
    inline constexpr uint16_t ServerPort = 1333;
    inline constexpr char ServerName[] = "ULTRA";
}
